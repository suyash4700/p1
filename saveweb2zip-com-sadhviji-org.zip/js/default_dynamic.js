
var header_height = 87;
var min_header_height_scroll = 57;
var min_header_height_sticky = 60;
var scroll_amount_for_sticky = 85;
var min_header_height_fixed_hidden = 45;
var header_bottom_border_weight = 1;
var scroll_amount_for_fixed_hiding = 200;
var menu_item_margin = 0;
var large_menu_item_border = 0;
var element_appear_amount = -150;
var paspartu_width_init = 0.02;
var directionNavArrows = 'arrow_carrot-';
var directionNavArrowsTestimonials = 'fa fa-angle-';
var enable_navigation_on_full_screen_section = false;
var add_for_admin_bar = 0;
	header_height = 35;
	min_header_height_scroll = 25;
	min_header_height_sticky = 40;
	scroll_amount_for_sticky = 230;




    paspartu_width_init = 0.012;

var logo_height = 130; // hudson logo height
var logo_width = 280; // hudson logo width
	    logo_width = 448;
    logo_height = 23;

		menu_item_margin = 0;
	
header_top_height= 30;
var loading_text;
loading_text = 'Loading new posts...';
var finished_text;
finished_text = 'No more posts';

var piechartcolor;
piechartcolor	= "#b48360";

	piechartcolor = "#ff8d0c";





var no_ajax_pages = [];
var edgt_root = 'https://sadhviji.org/';
var theme_root = 'https://sadhviji.org/wp-content/themes/hudsonwp/';
var header_style_admin = "light";
if(typeof no_ajax_obj !== 'undefined') {
no_ajax_pages = no_ajax_obj.no_ajax_pages;
}